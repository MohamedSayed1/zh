<?php


namespace App\ZH\Model;


use Illuminate\Database\Eloquent\Model;

class Moved extends Model
{

    protected $table ="move_appointment";

    protected $primaryKey ="move_id";

}