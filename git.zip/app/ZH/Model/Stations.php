<?php


namespace App\ZH\Model;


use Illuminate\Database\Eloquent\Model;

class Stations extends Model
{
    protected $table ="stations";
}
