<?php


namespace App\ZH\Model;


use Illuminate\Database\Eloquent\Model;

class Appointment extends Model
{

    protected $table ="appointment";
    protected $primaryKey ="app_id";
}