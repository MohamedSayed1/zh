<?php


namespace App\ZH\Model;


use Illuminate\Database\Eloquent\Model;

class userGroup extends Model
{

    protected $table ="user_group";
}