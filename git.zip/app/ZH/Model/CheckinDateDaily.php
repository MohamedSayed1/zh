<?php


namespace App\ZH\Model;


use Illuminate\Database\Eloquent\Model;

class CheckinDateDaily extends Model
{

    protected $table ="checkin_date_daily";
    protected $primaryKey="daily_id";
}