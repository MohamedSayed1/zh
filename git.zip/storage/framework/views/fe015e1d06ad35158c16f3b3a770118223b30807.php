

<?php $__env->startSection('title'); ?>
    user - updated
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <!-- start: TOOLBAR -->
    <div class="modal fade" id="panel-config" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        &times;
                    </button>
                    <h4 class="modal-title">Panel Configuration</h4>
                </div>
                <div class="modal-body">
                    Here will be a configuration form
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                        Close
                    </button>
                    <button type="button" class="btn btn-primary">
                        Save changes
                    </button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <div class="toolbar row">
        <div class="col-sm-6 hidden-xs">
            <div class="page-header">
                <h1>Users
                    <small>updated</small>
                </h1>
            </div>
        </div>
        <div class="col-sm-6 col-xs-12">

            <div class="toolbar-tools pull-right">
                <!-- start: TOP NAVIGATION MENU -->
                <ul class="nav navbar-right">
                    <!-- start: TO-DO DROPDOWN -->
                    <li class="dropdown">
                        <a href="<?php echo e(url('dashboard/users')); ?>" class="close-subviews">
                            <i class="fa fa-chevron-left"></i> BACK
                        </a>
                    </li>

                </ul>
                <!-- end: TOP NAVIGATION MENU -->
            </div>
        </div>
    </div>
    <!-- end: TOOLBAR -->
    <!-- end: PAGE HEADER -->
    <!-- start: BREADCRUMB -->
    <div class="row">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li>
                    <a href="<?php echo e(url('/dashboard')); ?>">
                        Home
                    </a>
                </li>
                <li class="active">
                    Users
                </li>
                <li class="active">
                    updated
                </li>
            </ol>
        </div>
    </div>

    <div class="row">

        <div class="col-sm-12">
            <!-- start: TEXT FIELDS PANEL -->
            <div class="panel panel-white table-panel" style="zoom: 1;">
                <div class="panel-heading">
                    <h4 class="panel-title"><span class="text-bold">updated info</span></h4>
                    <div class="panel-tools">
                        <div class="dropdown">
                            <a data-toggle="dropdown"
                               class="btn btn-xs dropdown-toggle btn-transparent-grey"
                               aria-expanded="false">
                                <i class="fa fa-cog"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-light pull-right" role="menu"
                                style="display: none;">
                                <li>
                                    <a class="panel-collapse collapses" href="#"><i
                                                class="fa fa-angle-up"></i> <span>Collapse</span> </a>
                                </li>
                                <li>
                                    <a class="panel-expand" href="#">
                                        <i class="fa fa-expand"></i> <span>Fullscreen</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <a class="btn btn-xs btn-link panel-close" href="#">
                            <i class="fa fa-times"></i>
                        </a>
                    </div>
                </div>

                <div>
                    <div class="row">
                        <div class="col-md-11">
                            <div class="noteWrap opened  col-md-11">

                                <form method="post" action="<?php echo e(url('dashboard/users/updated')); ?>">

                                    <div class="form-group">
                                        <div class="row">
                                            <label class="col-sm-2 control-label" for="">
                                                id
                                            </label>
                                            <div class="col-sm-4">
                                                <input type="text" placeholder="code" name="code"
                                                       value="<?php echo e(old('code')!=null?old('code'):$user->code); ?>" class="form-control" required>

                                                <?php if($errors->has('code')): ?>
                                                    <span class="help-block">
                                            <strong class="text-danger"><?php echo e($errors->first('code')); ?></strong>
                                        </span>
                                                <?php endif; ?>

                                            </div>


                                            <label class="col-sm-2 control-label" for="">
                                                Name
                                            </label>
                                            <div class="col-sm-4">
                                                <input type="text" placeholder="Name" name="name"
                                                       value="<?php echo e(old('name')!=null?old('name'):$user->name); ?>" class="form-control" required>

                                                <?php if($errors->has('name')): ?>
                                                    <span class="help-block">
                                            <strong class="text-danger"><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                                <?php endif; ?>

                                            </div>


                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="row">
                                            <label class="col-sm-2 control-label" for="">
                                                Station
                                            </label>
                                            <div class="col-sm-4">
                                                <select class="form-control" name="station">
                                                    <?php if(isset($stations)): ?>
                                                        <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($station->id); ?>"
                                                                    <?php if(old('station') != null): ?>
                                                                     <?php echo e(old('station') ==$station->id?'selected':''); ?>

                                                                    <?php else: ?>
                                                                      <?php echo e($user->station_id ==$station->id?'selected':''); ?>

                                                                    <?php endif; ?>
                                                            >
                                                                <?php echo e($station->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>

                                            <?php if(Auth()->user()->group_id == 1): ?>
                                            <label class="col-sm-2 control-label" for="">
                                                Groupe
                                            </label>
                                            <div class="col-sm-4">
                                                <select name="group" class="form-control">
                                                    <?php if(isset($groups)): ?>
                                                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($grou->id); ?>"
                                                                    <?php if(old('group') != null): ?>
                                                                    <?php echo e(old('group') ==$grou->id?'selected':''); ?>

                                                                    <?php else: ?>
                                                                        <?php echo e($user->group_id ==$grou->id?'selected':''); ?>

                                                                    <?php endif; ?>
                                                            >
                                                                <?php echo e($grou->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                            <?php endif; ?>


                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <div class="row">


                                            <label class="col-sm-2 control-label" for="">
                                                Phone
                                            </label>
                                            <div class="col-sm-4">
                                                <input type="text" placeholder="Phone" name="phone"
                                                       value="<?php echo e(old('phone')!=null?old('phone'):$user->phone); ?>" class="form-control" required>
                                                <?php if($errors->has('phone')): ?>
                                                    <span class="help-block">
                                            <strong class="text-danger"><?php echo e($errors->first('phone')); ?></strong>
                                        </span>
                                                <?php endif; ?>
                                            </div>

                                            <label class="col-sm-2 control-label" for="">
                                                parent phone
                                            </label>
                                            <div class="col-sm-4">
                                                <input type="text" placeholder="parent phone" name="parent_phone"
                                                       value="<?php echo e(old('parent_phone')!= null?old('parent_phone'):$user->parent_phone); ?>" class="form-control">
                                                <?php if($errors->has('parent_phone')): ?>
                                                    <span class="help-block">
                                            <strong class="text-danger"><?php echo e($errors->first('parent_phone')); ?></strong>
                                        </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="row">


                                            <label class="col-sm-2 control-label" for="">
                                                Fucilty
                                            </label>
                                            <div class="col-sm-4">
                                                <select class="form-control" name="faculty">
                                                    <?php if(isset($faclitys)): ?>
                                                        <?php $__currentLoopData = $faclitys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($key); ?>"
                                                            <?php if(old('faculty') != null): ?>
                                                                <?php echo e(old('faculty') == $key ?'selected':''); ?>

                                                                    <?php else: ?>
                                                                <?php echo e($user->faculty == $key ?'selected':''); ?>

                                                                    <?php endif; ?>
                                                            >
                                                                <?php echo e($value); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>

                                                <?php if($errors->has('faculty')): ?>
                                                    <span class="help-block">
                                            <strong class="text-danger"><?php echo e($errors->first('faculty')); ?></strong>
                                        </span>
                                                <?php endif; ?>
                                            </div>
                                            <label class="col-sm-2 control-label" for="">
                                                Educate Level
                                            </label>
                                            <div class="col-sm-4">
                                                <select class="form-control" name="educational_level">
                                                    <?php if(isset($levels)): ?>
                                                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($key); ?>"
                                                            <?php if(old('educational_level') != null): ?>
                                                                <?php echo e(old('educational_level') ==$key?'selected':''); ?>

                                                                    <?php else: ?>
                                                                <?php echo e($user->educational_level ==
                                                                $key?'selected':''); ?>

                                                                    <?php endif; ?>
                                                            >
                                                                <?php echo e($value); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>

                                                <?php if($errors->has('educational_level')): ?>
                                                    <span class="help-block">
                                            <strong class="text-danger"><?php echo e($errors->first('educational_level')); ?></strong>
                                        </span>
                                                <?php endif; ?>
                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group">
                                        <div class="row">
                                            <label class="col-sm-2 control-label" for="">
                                                Groupe
                                            </label>
                                            <div class="col-sm-4">
                                                <select name="active" class="form-control">
                                                            <option value="1"
                                                            <?php if(old('active') != null): ?>
                                                                <?php echo e(old('active') ==1?'selected':''); ?>

                                                                    <?php else: ?>
                                                                <?php echo e($user->is_active ==1?'selected':''); ?>

                                                                    <?php endif; ?>
                                                            >
                                                               Active
                                                            </option>
                                                    <option value="0"
                                                            <?php if(old('active') != null): ?>
                                                                <?php echo e(old('active') ==0?'selected':''); ?>

                                                                    <?php else: ?>
                                                                <?php echo e($user->is_active ==0?'selected':''); ?>

                                                                    <?php endif; ?>
                                                            >
                                                              unActive
                                                            </option>


                                                </select>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="row">
                                            <label class="col-sm-2 control-label" for="">
                                                Note
                                            </label>
                                            <div class="col-sm-10">
                                <textarea  placeholder="Note" name="note"
                                           class="form-control"><?php echo e(old('note')!=null?old('note'):$user->notes); ?>


                                </textarea>
                                            </div>

                                        </div>
                                    </div>
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">


                                    <div class="form-group ">
                                        <div class="row">
                                            <div class="col-sm-12 ">
                                                <div class="btn-group">
                                                    <a href="<?php echo e(url('dashboard/users')); ?>" class="btn btn-info inline-close">
                                                        back
                                                    </a>
                                                </div>
                                                <div class="btn-group">
                                                    <button type="submit" class="btn btn-info">
                                                        Save
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zhtransportation/public_html/resources/views/admin/users/updated.blade.php ENDPATH**/ ?>