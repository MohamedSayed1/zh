<?php $__env->startSection('title'); ?>
    subscribe
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start: PAGE HEADER -->
    <!-- start: TOOLBAR -->
    <div class="toolbar row">
        <div class="col-sm-6 hidden-xs">
            <div class="page-header">
                <h1>Subscribe <small>Index &amp; Details </small></h1>
            </div>
        </div>
        <div class="col-sm-6 col-xs-12">
            <a href="#" class="back-subviews">
                <i class="fa fa-chevron-left"></i> BACK
            </a>
            <a href="#" class="close-subviews">
                <i class="fa fa-times"></i> CLOSE
            </a>
            <div class="toolbar-tools pull-right">
                <!-- start: TOP NAVIGATION MENU -->
                <ul class="nav navbar-right">
                    <!-- start: TO-DO DROPDOWN -->
                    <li class="dropdown">
                        <a class="inline-open" href="#addSubscribe">
                            <i class="fa fa-plus"></i> Add Subscribe
                        </a>
                    </li>

                </ul>
                <!-- end: TOP NAVIGATION MENU -->
            </div>
        </div>
    </div>
    <!-- end: TOOLBAR -->
    <!-- end: PAGE HEADER -->
    <!-- start: BREADCRUMB -->
    <div class="row">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li>
                    <a href="<?php echo e(url('/')); ?>">
                        Home
                    </a>
                </li>
                <li class="active">
                    Subscribe
                </li>
            </ol>
        </div>
    </div>
    <!-- end: BREADCRUMB -->
    <!-- start: PAGE CONTENT -->
    <div class="row">
        <div class="col-sm-12">
            <!-- start: TEXT FIELDS PANEL -->
            <div class="panel panel-white table-panel" style="zoom: 1;">
                <div class="panel-heading">
                    <h4 class="panel-title"><span class="text-bold">Subscribe</span></h4>
                    <div class="panel-tools">
                        <div class="dropdown">
                            <a data-toggle="dropdown"
                               class="btn btn-xs dropdown-toggle btn-transparent-grey"
                               aria-expanded="false">
                                <i class="fa fa-cog"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-light pull-right" role="menu"
                                style="display: none;">
                                <li>
                                    <a class="panel-collapse collapses" href="#"><i
                                            class="fa fa-angle-up"></i> <span>Collapse</span> </a>
                                </li>
                                <li>
                                    <a class="panel-expand" href="#">
                                        <i class="fa fa-expand"></i> <span>Fullscreen</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <a class="btn btn-xs btn-link panel-close" href="#">
                            <i class="fa fa-times"></i>
                        </a>
                    </div>
                </div>


                <!-- Start: Add New subscribe Form -->
                <div class="inline-form1 <?php echo e($errors->any() ? 'opened' : 'closed'); ?>">
                    <div class="col-md-11">
                        <h3>Add new Subscribe</h3>
                        <hr>
                        <form action="<?php echo e(route('subscribe.store')); ?>" method="post">
                            <div class="form-group">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('post')); ?>

                                <div class="row">
                                    <label class="col-sm-2 control-label" for="">
                                        Student
                                    </label>
                                    
                                    <div class="col-sm-4">
                                        <select class="form-control" name="user_id">
                                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($student->id); ?>" <?php echo e(old('user_id')== $student->id ? 'selected' : ''); ?>><?php echo e($student->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['duplicated'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <label class="col-sm-2 control-label" for="">
                                        Payment settings
                                    </label>

                                    <div class="col-sm-4">
                                        <select class="form-control" name="payment_id">
                                            <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($method->setting_id); ?>" <?php echo e(old('payment_id')== $method->setting_id ? 'selected' : ''); ?>><?php echo e($method->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['payment_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <label class="col-sm-2 control-label" for="">
                                        Cost
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="number" step="any" id="total" class="form-control" name="total"
                                               placeholder="Enter the Cost"

                                               value="<?php echo e(old('total')); ?>" required oninput="makeDefault()">
                                        <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <label class="col-sm-2 control-label" for="">
                                        Term
                                    </label>
                                    
                                    <div class="col-sm-4">
                                        <select class="form-control" name="term_id">
                                            <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($term->term_id); ?>" <?php echo e(old('status')== $term->term_id ? 'selected' : ''); ?>><?php echo e($term->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php $__errorArgs = ['term_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <label class="col-sm-2 control-label" for="">
                                        current paid
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="number" step="any" id="paid" class="form-control" name="paid"

                                               value="<?php echo e(old('paid')??0); ?>" required  oninput="changeInformation()" >
                                        <?php $__errorArgs = ['paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <label class="col-sm-2 control-label" for="">
                                        Next payment date
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="date"  class="form-control" name="next_payment_date"

                                               value="<?php echo e(old('next_payment_date')); ?>"  >
                                        <?php $__errorArgs = ['next_payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <label class="col-sm-2 control-label" for="">
                                        NON-Paid
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="number" step="any" id="unpaid" class="form-control" name="unpaid"

                                               value="<?php echo e(old('unpaid')); ?>" required readonly>
                                        <?php $__errorArgs = ['unpaid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <label class="col-sm-2 control-label" for="">
                                        paid_percentage_(%)
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="text"  id="paid_percentage" class="form-control" name="paid_percentage"

                                               value="<?php echo e(old('paid_percentage')); ?>" required readonly>
                                        <?php $__errorArgs = ['paid_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <label class="col-sm-2 control-label" for="">
                                        Note
                                    </label>
                                    <div class="col-sm-10">
                                          <textarea placeholder="Note" name="note"
                                                    class="form-control">
                                            <?php echo e(old('note')); ?>

                                        </textarea>

                                        <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                </div>
                            </div>
                            <div class="form-group ">
                                <div class="row">
                                    <div class="col-sm-12 ">
                                        <div class="btn-group">
                                            <a href="#" class="btn btn-info inline-close">
                                                Close
                                            </a>
                                        </div>
                                        <div class="btn-group">
                                            <button class="btn btn-info ">
                                                Save
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>


                <!-- Start: Search user -->
                <div class="col-md-11">
                    <form action="<?php echo e(route('subscribe')); ?>" method="get">
                        <div class="form-group">
                            <div class="row">
                                <label class="col-sm-2 control-label" for="">
                                    search about student
                                </label>
                                <div class="col-sm-4">
                                    <input type="text" name="search" placeholder="search by Code or Name of student" value="<?php echo e(request()->search); ?>" class="form-control">
                                </div>
                                <div class="btn-group">
                                    <button class="btn btn-info ">
                                        Search
                                    </button>

                                </div>
                            </div>
                        </div>
                    </form>
                    <hr>
                </div>


            <?php if(count($subscribes)>0): ?>
                <!-- Start: subscribe Index Table -->
                    <table class="table table-hover table-striped">
                        <thead>
                        <tr>
                            <th>code</th>
                            <th>student</th>
                            <th>payment setting</th>
                            <th>cost</th>
                            <th>paid</th>
                            <th>unpaid</th>
                            <th>paid_percentage</th>
                            <th>received by</th>
                            <th>term</th>
                            <th>note</th>
                            <th>status</th>
                            <th>action</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $subscribes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$subscribe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($subscribe->code); ?></td>
                                <td><?php echo e($subscribe->user->name); ?></td>
                                <td><?php echo e($subscribe->paymentSetting->name); ?></td>
                                <td><?php echo e($subscribe->total); ?> LE</td>
                                <td><?php echo e($subscribe->paid); ?> LE</td>

                                <td><?php echo e($subscribe->unpaid); ?> LE</td>
                                <td><?php echo e($subscribe->paid_percentage); ?> %</td>
                                <td><?php echo e($subscribe->user2->name); ?></td>
                                <td><?php echo e($subscribe->term->name); ?></td>
                                <td><?php echo e($subscribe->note); ?></td>
                                <?php if($subscribe->status == 0): ?>
                                    <td class="text-success">مدفوعة</td>
                                <?php else: ?>
                                    <td class="text-danger">غير مدفوعة</td>
                                <?php endif; ?>
                                <td class="center">
                                    <div class="btn-group">
                                        <a href="#" class="dotsrow dropdown-toggle"
                                           data-toggle="dropdown"><i class="fa fa-ellipsis-h"></i></a>
                                        <ul class="dropdown-menu" role="menu">

                                            <li>
                                                <form id="formSubmit"
                                                      action="<?php echo e(route('subscribe.destroy',$subscribe->id)); ?>"
                                                      method="post" style="display: inline-block">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('delete')); ?>


                                                </form>
                                                <a href="" class=" delete123 "><i class="fa fa-trash"></i> delete</a>

                                            </li>

                                            <li>
                                                <a href="<?php echo e(route('subscribe.edit',$subscribe->id)); ?>"
                                                   class="inline-open ">
                                                    <i class="fa fa-edit"></i>
                                                    Edit
                                                </a>
                                            </li>

                                            <li>
                                                <a href="<?php echo e(route('subscribe.installment',$subscribe->id)); ?>">
                                                    <i class="fa fa-plus"></i>
                                                    pay in installments
                                                </a>
                                            </li>

                                        </ul>
                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                <?php else: ?>
                    <hr/>
                    <h2 class="center">oops....Empty. add new subscribes</h2>
                <?php endif; ?>
            </div>
        </div>
        <!-- end: TEXT FIELDS PANEL -->
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


    


    


    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    

    <script>
        function makeDefault() {

            var un_paid = parseFloat(document.getElementById("total").value);


            document.getElementById("paid").value = 0;
            document.getElementById("unpaid").value = parseFloat(un_paid).toFixed(2);
            document.getElementById("paid_percentage").value = 0;

            changeInformation();



        }

        function changeInformation() {

            var Total = parseFloat(document.getElementById("total").value);
            var Paid = parseFloat(document.getElementById("paid").value);

            var NOT_PAID = Total - Paid;



            if (typeof NOT_PAID === 'undefined'  ) {

                alert('برجاء ادخال دفعه من الاشتراك ');

            } else {
                var paidPercentage = (Paid / Total) * 100;

                non_paid = parseFloat(NOT_PAID).toFixed(2);

                document.getElementById("unpaid").value = non_paid;

                document.getElementById("paid_percentage").value = parseFloat(paidPercentage);

            }

        }

    </script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localhost\htdocs\zh\resources\views/admin/subscribe/index.blade.php ENDPATH**/ ?>