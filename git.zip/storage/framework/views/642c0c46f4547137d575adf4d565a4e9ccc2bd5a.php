<?php $__env->startSection('title'); ?>
    Installment - add
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- start: TOOLBAR -->
    <div class="toolbar row">
        <div class="col-sm-6 hidden-xs">
            <div class="page-header">
                <h1>Stations
                    <small>add info</small>
                </h1>
            </div>
        </div>
        <div class="col-sm-6 col-xs-12">
            <a href="#" class="back-subviews">
                <i class="fa fa-chevron-left"></i> BACK
            </a>
            <a href="#" class="close-subviews">
                <i class="fa fa-times"></i> CLOSE
            </a>
            <div class="toolbar-tools pull-right">
                <!-- start: TOP NAVIGATION MENU -->
                <ul class="nav navbar-right">
                    <!-- start: TO-DO DROPDOWN -->

                </ul>
                <!-- end: TOP NAVIGATION MENU -->
            </div>
        </div>
    </div>
    <!-- end: TOOLBAR -->
    <!-- end: PAGE HEADER -->
    <!-- start: BREADCRUMB -->
    <div class="row">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li>
                    <a href="<?php echo e(url('/')); ?>">
                        Home
                    </a>
                </li>
                <li class="active">
                    Installment New -<?php echo e($subscribe->user->name); ?> - code <?php echo e($subscribe->user->code); ?>

                </li>
            </ol>
        </div>
    </div>
    <!-- end: BREADCRUMB -->
    <!-- start: PAGE CONTENT -->
    <div class="row">
        <div class="col-sm-12">
            <!-- start: TEXT FIELDS PANEL -->
            <div class="panel panel-white table-panel" style="zoom: 1; overflow: scroll">
                <div class="panel-heading">
                    <h4 class="panel-title"><span class="text-bold">Installment</span></h4>
                    <div class="panel-tools">
                        <div class="dropdown">
                            <a data-toggle="dropdown"
                               class="btn btn-xs dropdown-toggle btn-transparent-grey"
                               aria-expanded="false">
                                <i class="fa fa-cog"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-light pull-right" role="menu"
                                style="display: none;">
                                <li>
                                    <a class="panel-collapse collapses" href="#"><i
                                            class="fa fa-angle-up"></i> <span>Collapse</span> </a>
                                </li>
                                <li>
                                    <a class="panel-expand" href="#">
                                        <i class="fa fa-expand"></i> <span>Fullscreen</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <a class="btn btn-xs btn-link panel-close" href="#">
                            <i class="fa fa-times"></i>
                        </a>
                    </div>
                </div>


                <!-- START: update subscription   -->

                <!-- Start: update  subscription Form -->
                <div class="inline-form1  opened" style="overflow: scroll">
                    <div class="col-md-11">
                        <h3>Installment New -<?php echo e($subscribe->user->name); ?> - code:   <?php echo e($subscribe->user->code); ?></h3>

                        <br> <br>

                        <form action="<?php echo e(route('subscribe.installment.store')); ?>" method="post">
                            <div class="form-group">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('post')); ?>

                                <input type="hidden" name="id" value="<?php echo e($subscribe->id); ?>">

                                <div class="form-group">
                                    <div class="row">
                                        <label class="col-sm-2 control-label" for="">
                                            Add New Payment (Installment)
                                        </label>
                                        <div class="col-sm-8">
                                            <input type="number" step="any" id="pay_debt" class="form-control" name="pay_debt"

                                                   value="<?php echo e(old('pay_debt')??0); ?>" required  oninput="changeInformation()" >
                                            <?php $__errorArgs = ['pay_debt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 control-label" for="">
                                        Student
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control"
                                                placeholder="" value="<?php echo e($subscribe->user->name); ?>"
                                               required readonly>

                                    </div>

                                    <label class="col-sm-2 control-label" for="">
                                        Payment settings
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control"
                                                placeholder="" value="<?php echo e($subscribe->paymentSetting->name); ?>"
                                                readonly>

                                    </div>


                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <label class="col-sm-2 control-label" for="">
                                        Cost
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="number"  step="any" class="form-control"

                                               value="<?php echo e($subscribe->total); ?>"  readonly>

                                    </div>

                                    <label class="col-sm-2 control-label" for="">
                                        term
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="text"  class="form-control"

                                               value=" <?php echo e($subscribe->term->name); ?>"  readonly>

                                    </div>



                                </div>
                            </div>
                            
                            <div class="form-group">
                                <div class="row">
                                    <label class="col-sm-2 control-label" for="">
                                        current paid
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="number" step="any"  class="form-control"

                                               value="<?php echo e($subscribe->paid); ?>"   readonly >

                                    </div>

                                    <label class="col-sm-2 control-label" for="">
                                        Next payment date
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="date"  class="form-control" name="next_payment_date"

                                               value="<?php echo e(old('next_payment_date')!= null ? old('next_payment_date') : $subscribe->next_payment_date); ?>"  >
                                        <?php $__errorArgs = ['next_payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <label class="col-sm-2 control-label" for="">
                                        NON-Paid
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="number" step="any"  class="form-control"

                                               value="<?php echo e($subscribe->unpaid); ?>"  readonly>

                                    </div>

                                    <label class="col-sm-2 control-label" for="">
                                        paid_percentage_(%)
                                    </label>
                                    <div class="col-sm-4">
                                        <input type="text"  id="paid_percentage" class="form-control"

                                               value="<?php echo e($subscribe->paid_percentage); ?>"  readonly>

                                    </div>
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="row">
                                    <label class="col-sm-2 control-label" for="">
                                        Note
                                    </label>
                                    <div class="col-sm-10">
                                          <textarea placeholder="Note" name="note"
                                                    class="form-control">
                                            <?php echo e(old('note')!= null ? old('note') : $subscribe->note); ?>

                                        </textarea>

                                        <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                </div>
                            </div>
                            <div class="form-group ">
                                <div class="row">
                                    <div class="col-sm-12 ">
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('subscribe')); ?>" class="btn btn-info inline-close">
                                                Close
                                            </a>
                                        </div>
                                        <div class="btn-group">
                                            <button class="btn btn-info ">
                                                Save
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                        
                        
                        
                        

                    </div>
                </div>


            </div>
        </div>
        <!-- end: TEXT FIELDS PANEL -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>































<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zhtransportation/public_html/resources/views/admin/subscribe/add_installment.blade.php ENDPATH**/ ?>